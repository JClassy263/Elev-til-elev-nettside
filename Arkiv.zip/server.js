import express from "express";
import dotenv from "dotenv";
import path from "path";
import fetch from "node-fetch";

dotenv.config();

const app = express();
app.use(express.json());

// Serve static files from public folder
app.use(express.static(path.join(process.cwd(), "public")));

// Fallback for root /
app.get("/", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public", "index.html"));
});

// Chat API
app.post("/api/chat", async (req, res) => {
    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + process.env.OPENAI_API_KEY
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    {
                        role: "system",
                        content: "Du er en KI-assistent som kun gir råd om hverdagsvaner som søvn, mat, trening og daglige rutiner. Ignorer alle andre emner. Gi praktiske og konkrete forbedrings tips. vær sprørrede for å finne ut løsningen rettet til brukeren. om brukeren ikke har noe kan du komme med et enkelt eksempel. Svar kortfattet."
                    },
                    ...req.body.messages
                ]
            })
        });

        const data = await response.json();

        if (!response.ok) {
            console.error(data);
            return res.status(response.status).send(data);
        }

        res.send(data);

    } catch (err) {
        console.error(err);
        res.status(500).send({ error: err.message });
    }
});

// Start server
app.listen(3000, () => console.log("Server kjører på port 3000"));
